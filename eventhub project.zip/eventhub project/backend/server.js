// ============================================================
// server.js – Express App Entry Point
// ============================================================
const express = require("express");
const cors    = require("cors");
const dotenv  = require("dotenv");
const connectDB = require("./config/db");

dotenv.config();
connectDB();

const app = express();

// Middleware
app.use(cors({ origin: process.env.CLIENT_URL || "*" }));
app.use(express.json());
app.use(express.urlencoded({ extended: true }));

// Routes
app.use("/api/auth",   require("./routes/auth"));
app.use("/api/events", require("./routes/events"));
app.use("/api/users",  require("./routes/users"));

// Health check
app.get("/", (req, res) => res.json({ message: "Event Hub API is running 🎓" }));

const PORT = process.env.PORT || 5000;
app.listen(PORT, () => console.log(`🚀 Server running on port ${PORT}`));

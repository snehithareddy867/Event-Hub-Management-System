// ============================================================
// Event.js – Mongoose Schema for Events
// ============================================================
const mongoose = require("mongoose");

const eventSchema = new mongoose.Schema(
  {
    title:       { type: String, required: true, trim: true },
    description: { type: String, required: true },
    shortDesc:   { type: String, default: "" },
    category: {
      type: String,
      enum: ["technical", "cultural", "sports", "workshop", "seminar", "other"],
      default: "other",
    },
    startDate:   { type: Date, required: true },
    endDate:     { type: Date, required: true },
    venue:       { type: String, default: "Vignan University Campus" },
    images:      [{ type: String }],              // array of image URLs
    coverImage:  { type: String, default: "" },
    organizer:   { type: mongoose.Schema.Types.ObjectId, ref: "User" },
    registrations: [{ type: mongoose.Schema.Types.ObjectId, ref: "User" }],
    maxCapacity: { type: Number, default: 500 },
    isUpcoming:  { type: Boolean, default: true },
    isPast:      { type: Boolean, default: false },
    // Hospitality details
    howToReach:      { type: String, default: "" },
    accommodation:   { type: String, default: "" },
    contactInfo:     { type: String, default: "" },
    instructions:    { type: String, default: "" },
  },
  { timestamps: true }
);

module.exports = mongoose.model("Event", eventSchema);

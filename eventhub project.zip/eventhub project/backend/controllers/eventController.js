// ============================================================
// eventController.js – CRUD for Events + registration stats
// ============================================================
const Event        = require("../models/Event");
const Registration = require("../models/Registration");

// GET /api/events
const getAllEvents = async (req, res) => {
  try {
    const events = await Event.find()
      .populate("organizer", "name email")
      .sort({ startDate: 1 });
    res.json(events);
  } catch (err) { res.status(500).json({ message: err.message }); }
};

// GET /api/events/:id
const getEventById = async (req, res) => {
  try {
    const event = await Event.findById(req.params.id)
      .populate("organizer", "name email")
      .populate("registrations", "name email role studentId");
    if (!event) return res.status(404).json({ message: "Event not found" });
    res.json(event);
  } catch (err) { res.status(500).json({ message: err.message }); }
};

// GET /api/events/:id/registrations  (organizer only – full list)
const getEventRegistrations = async (req, res) => {
  try {
    const regs = await Registration.find({ event: req.params.id })
      .populate("user", "name email role studentId college")
      .sort({ registeredAt: -1 });
    res.json({
      total: regs.length,
      registrations: regs,
    });
  } catch (err) { res.status(500).json({ message: err.message }); }
};

// POST /api/events  (organizer only)
const createEvent = async (req, res) => {
  try {
    const event = await Event.create({ ...req.body, organizer: req.user._id });
    res.status(201).json(event);
  } catch (err) { res.status(500).json({ message: err.message }); }
};

// PUT /api/events/:id  (organizer only)
const updateEvent = async (req, res) => {
  try {
    const event = await Event.findByIdAndUpdate(req.params.id, req.body, { new: true });
    if (!event) return res.status(404).json({ message: "Event not found" });
    res.json(event);
  } catch (err) { res.status(500).json({ message: err.message }); }
};

// DELETE /api/events/:id  (organizer only)
const deleteEvent = async (req, res) => {
  try {
    await Event.findByIdAndDelete(req.params.id);
    await Registration.deleteMany({ event: req.params.id });
    res.json({ message: "Event deleted" });
  } catch (err) { res.status(500).json({ message: err.message }); }
};

// POST /api/events/:id/register
const registerForEvent = async (req, res) => {
  try {
    const reg = await Registration.create({ user: req.user._id, event: req.params.id });
    await Event.findByIdAndUpdate(req.params.id, { $addToSet: { registrations: req.user._id } });
    res.status(201).json({ message: "Registered successfully", registration: reg });
  } catch (err) {
    if (err.code === 11000) return res.status(400).json({ message: "Already registered for this event" });
    res.status(500).json({ message: err.message });
  }
};

// DELETE /api/events/:id/register  (cancel registration)
const cancelRegistration = async (req, res) => {
  try {
    await Registration.findOneAndDelete({ user: req.user._id, event: req.params.id });
    await Event.findByIdAndUpdate(req.params.id, { $pull: { registrations: req.user._id } });
    res.json({ message: "Registration cancelled" });
  } catch (err) { res.status(500).json({ message: err.message }); }
};

module.exports = {
  getAllEvents, getEventById, getEventRegistrations,
  createEvent, updateEvent, deleteEvent,
  registerForEvent, cancelRegistration,
};

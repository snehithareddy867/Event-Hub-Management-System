// ============================================================
// userController.js – User profile & registrations
// ============================================================
const User = require("../models/User");
const Registration = require("../models/Registration");

// GET /api/users/profile
const getProfile = async (req, res) => {
  try {
    const user = await User.findById(req.user._id).select("-password");
    res.json(user);
  } catch (err) { res.status(500).json({ message: err.message }); }
};

// GET /api/users/registered-events
const getRegisteredEvents = async (req, res) => {
  try {
    const regs = await Registration.find({ user: req.user._id }).populate("event");
    res.json(regs.map((r) => r.event));
  } catch (err) { res.status(500).json({ message: err.message }); }
};

module.exports = { getProfile, getRegisteredEvents };

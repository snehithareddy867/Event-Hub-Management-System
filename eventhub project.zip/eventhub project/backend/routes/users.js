// ============================================================
// routes/users.js – User profile routes
// ============================================================
const express = require("express");
const router = express.Router();
const { protect } = require("../middleware/authMiddleware");
const { getProfile, getRegisteredEvents } = require("../controllers/userController");

router.get("/profile",           protect, getProfile);
router.get("/registered-events", protect, getRegisteredEvents);

module.exports = router;

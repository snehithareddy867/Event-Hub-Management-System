// ============================================================
// routes/events.js
// ============================================================
const express = require("express");
const router  = express.Router();
const { protect, organizerOnly } = require("../middleware/authMiddleware");
const {
  getAllEvents, getEventById, getEventRegistrations,
  createEvent, updateEvent, deleteEvent,
  registerForEvent, cancelRegistration,
} = require("../controllers/eventController");

router.get("/",                          getAllEvents);
router.get("/:id",                       getEventById);
router.get("/:id/registrations",         protect, organizerOnly, getEventRegistrations);
router.post("/",                         protect, organizerOnly, createEvent);
router.put("/:id",                       protect, organizerOnly, updateEvent);
router.delete("/:id",                    protect, organizerOnly, deleteEvent);
router.post("/:id/register",             protect, registerForEvent);
router.delete("/:id/register",           protect, cancelRegistration);

module.exports = router;

// ============================================================
// seed.js – Seeds 11 users + 50 events (10 per category, 2026)
// Run: node seed.js
// ============================================================
const mongoose = require("mongoose");
const bcrypt   = require("bcryptjs");
const dotenv   = require("dotenv");
dotenv.config();

const User         = require("./models/User");
const Event        = require("./models/Event");
const Registration = require("./models/Registration");

const USERS = [
  { name:"Snehitha Reddy",  email:"snehitha@vignan.ac.in", password:"student123",   role:"student",   studentId:"22PA1A0501" },
  { name:"Ravi Kumar",      email:"ravi@vignan.ac.in",     password:"student123",   role:"student",   studentId:"22PA1A0502" },
  { name:"Ananya Sharma",   email:"ananya@vignan.ac.in",   password:"student123",   role:"student",   studentId:"22PA1A0503" },
  { name:"Kiran Babu",      email:"kiran@vignan.ac.in",    password:"student123",   role:"student",   studentId:"22PA1A0504" },
  { name:"Divya Nair",      email:"divya@vignan.ac.in",    password:"student123",   role:"student",   studentId:"22PA1A0505" },
  { name:"Dr. Prasad",      email:"prasad@vignan.ac.in",   password:"organizer123", role:"organizer" },
  { name:"Prof. Lakshmi",   email:"lakshmi@vignan.ac.in",  password:"organizer123", role:"organizer" },
  { name:"Dr. Ramesh",      email:"ramesh@vignan.ac.in",   password:"organizer123", role:"organizer" },
  { name:"Arjun Mehta",     email:"arjun@gmail.com",       password:"external123",  role:"external",  college:"JNTU Hyderabad" },
  { name:"Priya Singh",     email:"priya@gmail.com",       password:"external123",  role:"external",  college:"VIT Vellore" },
  { name:"Rahul Verma",     email:"rahul@gmail.com",       password:"external123",  role:"external",  college:"NIT Warangal" },
];

const ti = "https://images.unsplash.com/photo-1540575467063-178a50c2df87?w=600&q=80";
const ci = "https://images.unsplash.com/photo-1492684223066-81342ee5ff30?w=600&q=80";
const si = "https://images.unsplash.com/photo-1461896836934-ffe607ba8211?w=600&q=80";
const wi = "https://images.unsplash.com/photo-1517048676732-d65bc937f952?w=600&q=80";
const sei= "https://images.unsplash.com/photo-1475721027785-f74eccf877e2?w=600&q=80";

const EVENTS = [
  {title:"TechFest 2026",category:"technical",startDate:"2026-09-10",endDate:"2026-09-12",venue:"Main Auditorium",maxCapacity:800,shortDesc:"Annual flagship tech fest with 50+ events.",description:"TechFest 2026 is Vignan's premier technical festival featuring hackathons, robotics challenges, coding contests, paper presentations and talks from top industry leaders.",coverImage:ti,contactInfo:"techfest@vignan.ac.in",isUpcoming:true},
  {title:"Hackathon 2026",category:"technical",startDate:"2026-04-18",endDate:"2026-04-19",venue:"Innovation Lab",maxCapacity:200,shortDesc:"48-hour non-stop hackathon with Rs.5L prizes.",description:"Teams of 3-4 build real-world solutions in 48 hours. Mentors from Google, Microsoft and Amazon. Cash prizes worth Rs.5 Lakhs.",coverImage:ti,contactInfo:"hackathon@vignan.ac.in",isUpcoming:true},
  {title:"Robo Wars 2026",category:"technical",startDate:"2026-05-22",endDate:"2026-05-23",venue:"Engineering Block B",maxCapacity:300,shortDesc:"Combat robotics championship with live arena battles.",description:"Design and build your fighting robot and compete in the arena. Open to all engineering students. Prizes for top 3 teams.",coverImage:ti,contactInfo:"robotics@vignan.ac.in",isUpcoming:true},
  {title:"Code Sprint 2026",category:"technical",startDate:"2026-06-14",endDate:"2026-06-14",venue:"Computer Lab 1",maxCapacity:150,shortDesc:"3-hour competitive programming contest.",description:"Solve algorithmic challenges ranked by difficulty. Individual participation. Top performers get Amazon gift cards.",coverImage:ti,contactInfo:"cse@vignan.ac.in",isUpcoming:true},
  {title:"AI Hackathon",category:"technical",startDate:"2026-07-05",endDate:"2026-07-06",venue:"Seminar Hall B",maxCapacity:180,shortDesc:"Build AI/ML models to solve real-world problems.",description:"Participants receive curated datasets and 24 hours to build and present AI solutions. Expert judging panel from IIT and industry.",coverImage:ti,contactInfo:"aiml@vignan.ac.in",isUpcoming:true},
  {title:"Web Dev Championship",category:"technical",startDate:"2026-08-01",endDate:"2026-08-02",venue:"Lab Block 3",maxCapacity:120,shortDesc:"Full-stack web development competition.",description:"Build a complete full-stack web application in 24 hours based on a given theme. Individual or pair participation allowed.",coverImage:ti,contactInfo:"webdev@vignan.ac.in",isUpcoming:true},
  {title:"Cloud Computing Summit",category:"technical",startDate:"2026-10-03",endDate:"2026-10-03",venue:"Conference Hall A",maxCapacity:250,shortDesc:"AWS, Azure, GCP talks by certified architects.",description:"A one-day summit featuring cloud architecture deep dives, live demos and hands-on labs. AWS credits for all participants.",coverImage:ti,contactInfo:"cloud@vignan.ac.in",isUpcoming:true},
  {title:"Cybersecurity CTF",category:"technical",startDate:"2026-11-07",endDate:"2026-11-08",venue:"Cyber Lab",maxCapacity:100,shortDesc:"Capture The Flag security challenge event.",description:"Test your ethical hacking, forensics and cryptography skills. 24-hour CTF competition with industry-recognized certificates.",coverImage:ti,contactInfo:"security@vignan.ac.in",isUpcoming:true},
  {title:"IoT Expo 2026",category:"technical",startDate:"2026-01-15",endDate:"2026-01-16",venue:"Exhibition Hall",maxCapacity:400,shortDesc:"Internet of Things project showcase and competition.",description:"Students showcase IoT prototypes solving real-world problems. Projects judged on innovation, impact and technical execution.",coverImage:ti,contactInfo:"iot@vignan.ac.in",isUpcoming:false},
  {title:"App Dev Bootcamp",category:"technical",startDate:"2026-02-20",endDate:"2026-02-22",venue:"Mobile Lab",maxCapacity:80,shortDesc:"3-day Android and iOS development bootcamp.",description:"Learn to build and deploy mobile apps from scratch. Hands-on sessions with React Native and Flutter. Certificate on completion.",coverImage:ti,contactInfo:"appdev@vignan.ac.in",isUpcoming:false},

  {title:"Cultural Night 2026",category:"cultural",startDate:"2026-10-15",endDate:"2026-10-15",venue:"Open Air Theatre",maxCapacity:1500,shortDesc:"Grand cultural extravaganza with celebrity performers.",description:"A spectacular evening of music, dance, drama, fashion and celebrity performances celebrating the rich cultural diversity of Vignan.",coverImage:ci,contactInfo:"cultural@vignan.ac.in",isUpcoming:true},
  {title:"Vignan Utsav 2026",category:"cultural",startDate:"2026-03-21",endDate:"2026-03-23",venue:"Campus Grounds",maxCapacity:2000,shortDesc:"3-day cultural festival — the biggest on campus.",description:"Vignan Utsav is our annual 3-day mega cultural event featuring 30+ competitions, food stalls, art exhibitions and live performances.",coverImage:ci,contactInfo:"utsav@vignan.ac.in",isUpcoming:true},
  {title:"Classical Dance Fest",category:"cultural",startDate:"2026-04-10",endDate:"2026-04-10",venue:"Auditorium",maxCapacity:600,shortDesc:"Showcase of Bharatanatyam, Kuchipudi and folk dance.",description:"A mesmerizing evening of classical dance performances by students and guest artists. Competitions in Bharatanatyam, Kuchipudi and folk dance categories.",coverImage:ci,contactInfo:"arts@vignan.ac.in",isUpcoming:true},
  {title:"Battle of Bands",category:"cultural",startDate:"2026-05-30",endDate:"2026-05-30",venue:"Open Air Stage",maxCapacity:800,shortDesc:"Live band competition — rock, fusion and indie.",description:"Student bands compete across genres — rock, indie, fusion and classical. Wild card entry available for solo performers.",coverImage:ci,contactInfo:"music@vignan.ac.in",isUpcoming:true},
  {title:"Fine Arts Exhibition",category:"cultural",startDate:"2026-06-20",endDate:"2026-06-22",venue:"Art Gallery Hall",maxCapacity:500,shortDesc:"3-day exhibition of paintings, sculptures and digital art.",description:"Annual fine arts showcase featuring works across painting, sculpture, photography, installation art and digital media.",coverImage:ci,contactInfo:"fineart@vignan.ac.in",isUpcoming:true},
  {title:"Talent Hunt 2026",category:"cultural",startDate:"2026-07-18",endDate:"2026-07-18",venue:"Main Auditorium",maxCapacity:700,shortDesc:"Multi-talent competition across singing, dance and comedy.",description:"The biggest talent search on campus. Compete in singing, dancing, stand-up comedy or any unique talent. 3 rounds, cash prizes.",coverImage:ci,contactInfo:"talent@vignan.ac.in",isUpcoming:true},
  {title:"Street Play Competition",category:"cultural",startDate:"2026-08-25",endDate:"2026-08-25",venue:"Main Quad",maxCapacity:400,shortDesc:"Nukkad Natak event with social awareness themes.",description:"Teams perform 10-minute street plays on themes of social relevance. Judged on script, performance and audience impact.",coverImage:ci,contactInfo:"drama@vignan.ac.in",isUpcoming:true},
  {title:"Photography Contest",category:"cultural",startDate:"2026-09-05",endDate:"2026-09-05",venue:"Online + Campus",maxCapacity:300,shortDesc:"Theme-based photography competition with cash prizes.",description:"Submit your best photographs under the given theme. Expert photography professionals judge the entries.",coverImage:ci,contactInfo:"photo@vignan.ac.in",isUpcoming:true},
  {title:"Freshers Welcome 2026",category:"cultural",startDate:"2026-01-10",endDate:"2026-01-10",venue:"Auditorium",maxCapacity:1000,shortDesc:"Grand welcome event for new students.",description:"A warm welcome event for the 2026 batch featuring cultural performances, introductions, games and the crowning of Mr. and Ms. Fresher.",coverImage:ci,contactInfo:"student.affairs@vignan.ac.in",isUpcoming:false},
  {title:"Farewell Night 2026",category:"cultural",startDate:"2026-03-01",endDate:"2026-03-01",venue:"Rooftop Venue",maxCapacity:600,shortDesc:"Farewell party for graduating batch of 2026.",description:"A heartfelt send-off for the graduating batch with memories, performances, awards and a grand dinner.",coverImage:ci,contactInfo:"student.affairs@vignan.ac.in",isUpcoming:false},

  {title:"Sports Carnival 2026",category:"sports",startDate:"2026-11-14",endDate:"2026-11-16",venue:"Sports Complex",maxCapacity:1000,shortDesc:"Inter-college sports meet across 20+ disciplines.",description:"Vignan's biggest sporting event bringing together students from 30+ colleges. 20+ sports disciplines, medal ceremony and prizes.",coverImage:si,contactInfo:"sports@vignan.ac.in",isUpcoming:true},
  {title:"Cricket Premier League",category:"sports",startDate:"2026-04-01",endDate:"2026-04-30",venue:"Cricket Ground",maxCapacity:500,shortDesc:"Inter-department T20 cricket tournament.",description:"Month-long T20 cricket tournament featuring all departments. Draft selection, team jerseys and a grand final on the last day.",coverImage:si,contactInfo:"cricket@vignan.ac.in",isUpcoming:true},
  {title:"Basketball Tourney",category:"sports",startDate:"2026-05-10",endDate:"2026-05-12",venue:"Basketball Court",maxCapacity:300,shortDesc:"3-on-3 and 5-on-5 basketball championships.",description:"Exciting basketball tournament with separate categories for boys and girls. Both 3-on-3 streetball and 5-on-5 formats.",coverImage:si,contactInfo:"basketball@vignan.ac.in",isUpcoming:true},
  {title:"Badminton Open 2026",category:"sports",startDate:"2026-06-06",endDate:"2026-06-07",venue:"Indoor Stadium",maxCapacity:200,shortDesc:"Singles and doubles badminton championship.",description:"Open badminton championship with men's singles, women's singles and mixed doubles categories. Cash prizes and trophies.",coverImage:si,contactInfo:"badminton@vignan.ac.in",isUpcoming:true},
  {title:"Marathon 2026",category:"sports",startDate:"2026-07-26",endDate:"2026-07-26",venue:"Campus Circuit",maxCapacity:600,shortDesc:"5K and 10K run around campus and surrounding roads.",description:"Annual run-for-fitness event with 5K and 10K categories. Medals for all finishers, prizes for top 5 in each category.",coverImage:si,contactInfo:"athletics@vignan.ac.in",isUpcoming:true},
  {title:"Football Fest 2026",category:"sports",startDate:"2026-08-08",endDate:"2026-08-10",venue:"Football Ground",maxCapacity:400,shortDesc:"Inter-department 7-a-side football championship.",description:"3-day 7-a-side football tournament. Group stage followed by knockouts and grand final. Boys and girls categories.",coverImage:si,contactInfo:"football@vignan.ac.in",isUpcoming:true},
  {title:"Table Tennis Open",category:"sports",startDate:"2026-09-19",endDate:"2026-09-20",venue:"TT Hall",maxCapacity:100,shortDesc:"Singles and doubles TT championship.",description:"Vignan Table Tennis Open with rankings-based seeding. Best of 5 games format. Prizes for singles and doubles winners.",coverImage:si,contactInfo:"tt@vignan.ac.in",isUpcoming:true},
  {title:"Chess Tournament 2026",category:"sports",startDate:"2026-10-24",endDate:"2026-10-25",venue:"Conference Room B",maxCapacity:80,shortDesc:"Swiss system chess tournament with 7 rounds.",description:"7-round Swiss chess tournament with 30-minute time controls. Rated and unrated categories. Trophies and cash prizes.",coverImage:si,contactInfo:"chess@vignan.ac.in",isUpcoming:true},
  {title:"Aquatics Meet 2026",category:"sports",startDate:"2026-01-25",endDate:"2026-01-26",venue:"Swimming Pool",maxCapacity:150,shortDesc:"Swimming and diving championships.",description:"Annual aquatics meet featuring freestyle, backstroke, butterfly and relay events. Open to all registered students.",coverImage:si,contactInfo:"aquatics@vignan.ac.in",isUpcoming:false},
  {title:"Volleyball Classic",category:"sports",startDate:"2026-02-14",endDate:"2026-02-15",venue:"Volleyball Court",maxCapacity:200,shortDesc:"Indoor volleyball tournament for men and women.",description:"Inter-department volleyball tournament. 6-a-side format with beach volleyball exhibition matches on day 2.",coverImage:si,contactInfo:"volleyball@vignan.ac.in",isUpcoming:false},

  {title:"React.js Bootcamp",category:"workshop",startDate:"2026-04-25",endDate:"2026-04-26",venue:"Lab Block 3",maxCapacity:60,shortDesc:"2-day hands-on React.js development workshop.",description:"Build real React projects from scratch over 2 intensive days. Covers hooks, state management, API integration and deployment. Certificate provided.",coverImage:wi,contactInfo:"workshops@vignan.ac.in",isUpcoming:true},
  {title:"Machine Learning Lab",category:"workshop",startDate:"2026-05-16",endDate:"2026-05-17",venue:"AI Research Lab",maxCapacity:50,shortDesc:"Hands-on ML with Python, Scikit-learn and TensorFlow.",description:"2-day lab covering data preprocessing, model building, evaluation and deployment. Each participant gets a GPU cloud instance.",coverImage:wi,contactInfo:"mlworkshop@vignan.ac.in",isUpcoming:true},
  {title:"PCB Design Workshop",category:"workshop",startDate:"2026-06-13",endDate:"2026-06-14",venue:"ECE Lab",maxCapacity:40,shortDesc:"Design and fabricate your own PCB using KiCad.",description:"Learn PCB design from schematic to fabrication. Hands-on practice with KiCad. Each student takes home a fabricated board.",coverImage:wi,contactInfo:"ece.dept@vignan.ac.in",isUpcoming:true},
  {title:"AutoCAD Workshop 2026",category:"workshop",startDate:"2026-07-11",endDate:"2026-07-12",venue:"Civil Lab",maxCapacity:45,shortDesc:"2D and 3D CAD drafting with AutoCAD 2026.",description:"Learn professional CAD drafting for mechanical and civil engineering. Covers 2D drawings, 3D modeling and rendering.",coverImage:wi,contactInfo:"mech.dept@vignan.ac.in",isUpcoming:true},
  {title:"DevOps and Docker",category:"workshop",startDate:"2026-08-15",endDate:"2026-08-15",venue:"Server Room Lab",maxCapacity:55,shortDesc:"1-day Docker, Kubernetes and CI/CD pipeline workshop.",description:"Practical session on containerization with Docker, orchestration with Kubernetes and building CI/CD pipelines with GitHub Actions.",coverImage:wi,contactInfo:"devops@vignan.ac.in",isUpcoming:true},
  {title:"UI/UX Design Sprint",category:"workshop",startDate:"2026-09-26",endDate:"2026-09-27",venue:"Design Studio",maxCapacity:35,shortDesc:"Figma-based product design sprint over 2 days.",description:"Design a complete mobile app from user research to hi-fi prototype using Figma. Design critique sessions with industry UX designers.",coverImage:wi,contactInfo:"design@vignan.ac.in",isUpcoming:true},
  {title:"Ethical Hacking Workshop",category:"workshop",startDate:"2026-10-10",endDate:"2026-10-11",venue:"Cyber Lab",maxCapacity:40,shortDesc:"Beginner to intermediate ethical hacking hands-on.",description:"Learn penetration testing, network scanning, vulnerability assessment and exploitation in a safe lab environment.",coverImage:wi,contactInfo:"security@vignan.ac.in",isUpcoming:true},
  {title:"Data Visualization Workshop",category:"workshop",startDate:"2026-11-21",endDate:"2026-11-21",venue:"Stats Lab",maxCapacity:60,shortDesc:"Power BI and Tableau dashboard building workshop.",description:"1-day workshop covering data storytelling, dashboard design and interactive visualization using Power BI and Tableau with real datasets.",coverImage:wi,contactInfo:"datascience@vignan.ac.in",isUpcoming:true},
  {title:"Arduino for Beginners",category:"workshop",startDate:"2026-01-17",endDate:"2026-01-18",venue:"Electronics Lab",maxCapacity:50,shortDesc:"Build 5 Arduino projects in 2 days.",description:"Hands-on introduction to microcontrollers using Arduino. Build LED circuits, sensors, servo motors and a mini home automation demo.",coverImage:wi,contactInfo:"ieee@vignan.ac.in",isUpcoming:false},
  {title:"Python for Data Science",category:"workshop",startDate:"2026-02-28",endDate:"2026-03-01",venue:"Computer Lab 2",maxCapacity:70,shortDesc:"2-day Python workshop covering NumPy, Pandas, Matplotlib.",description:"Master Python for data analysis. Hands-on with real datasets, exploratory data analysis, visualization and basic machine learning.",coverImage:wi,contactInfo:"python@vignan.ac.in",isUpcoming:false},

  {title:"AI and Future of Work",category:"seminar",startDate:"2026-05-08",endDate:"2026-05-08",venue:"Conference Hall A",maxCapacity:350,shortDesc:"Industry leaders discuss AI impact on jobs and skills.",description:"A full-day seminar featuring keynotes, panel discussions and Q&A sessions on how AI is transforming industries and what skills will matter most in 2030.",coverImage:sei,contactInfo:"aiml@vignan.ac.in",isUpcoming:true},
  {title:"Startup Launchpad 2026",category:"seminar",startDate:"2026-06-27",endDate:"2026-06-27",venue:"Business School",maxCapacity:300,shortDesc:"Pitch to VCs and learn from unicorn founders.",description:"Annual entrepreneurship seminar with pitch competitions, fireside chats with founders of funded startups, and a networking dinner.",coverImage:sei,contactInfo:"startup@vignan.ac.in",isUpcoming:true},
  {title:"Research Symposium 2026",category:"seminar",startDate:"2026-07-04",endDate:"2026-07-05",venue:"Seminar Hall A",maxCapacity:200,shortDesc:"Paper presentations by UG, PG and PhD scholars.",description:"2-day academic symposium. Submit and present your research papers. Best papers get published in the Vignan University Journal.",coverImage:sei,contactInfo:"research@vignan.ac.in",isUpcoming:true},
  {title:"Industry Connect 2026",category:"seminar",startDate:"2026-08-22",endDate:"2026-08-22",venue:"Auditorium",maxCapacity:500,shortDesc:"HR leaders from top companies share hiring insights.",description:"Pre-placement seminar with HR leaders from TCS, Infosys, Amazon and Google sharing interview tips, career paths and hiring trends.",coverImage:sei,contactInfo:"placements@vignan.ac.in",isUpcoming:true},
  {title:"Mental Health Awareness",category:"seminar",startDate:"2026-09-10",endDate:"2026-09-10",venue:"Psychology Room",maxCapacity:150,shortDesc:"Talk on student wellbeing, stress and mental health.",description:"A sensitization seminar by certified psychologists covering academic stress, anxiety management, mindfulness and when to seek help.",coverImage:sei,contactInfo:"counselling@vignan.ac.in",isUpcoming:true},
  {title:"Women in STEM 2026",category:"seminar",startDate:"2026-10-08",endDate:"2026-10-08",venue:"Seminar Hall B",maxCapacity:250,shortDesc:"Celebrating and inspiring women in technology.",description:"Panel of women leaders from tech share their journeys. Sessions on breaking bias, building networks and leadership in STEM fields.",coverImage:sei,contactInfo:"womeninstem@vignan.ac.in",isUpcoming:true},
  {title:"Green Technology Forum",category:"seminar",startDate:"2026-11-05",endDate:"2026-11-05",venue:"Eco Hall",maxCapacity:200,shortDesc:"Sustainable tech and clean energy discussions.",description:"Seminar on solar energy, EVs, waste management and climate tech. Includes project showcase by environmental engineering students.",coverImage:sei,contactInfo:"green@vignan.ac.in",isUpcoming:true},
  {title:"Blockchain and Web3",category:"seminar",startDate:"2026-12-03",endDate:"2026-12-03",venue:"Conference Hall B",maxCapacity:180,shortDesc:"DeFi, NFTs and the decentralized web explained.",description:"Expert-led seminar on blockchain fundamentals, smart contracts, DeFi protocols and career opportunities in the Web3 ecosystem.",coverImage:sei,contactInfo:"blockchain@vignan.ac.in",isUpcoming:true},
  {title:"Alumni Speaks 2026",category:"seminar",startDate:"2026-01-30",endDate:"2026-01-30",venue:"Auditorium",maxCapacity:400,shortDesc:"Vignan alumni share their professional journeys.",description:"5 accomplished alumni from different career paths share their stories, lessons learned and advice for students about to enter the workforce.",coverImage:sei,contactInfo:"alumni@vignan.ac.in",isUpcoming:false},
  {title:"Career Guidance Seminar",category:"seminar",startDate:"2026-02-21",endDate:"2026-02-21",venue:"Seminar Hall A",maxCapacity:300,shortDesc:"GATE, GRE, MBA and placement preparation roadmap.",description:"Comprehensive career guidance session covering GATE preparation, GRE/GMAT for higher studies, government jobs and corporate placement strategies.",coverImage:sei,contactInfo:"career@vignan.ac.in",isUpcoming:false},
];

async function seed() {
  try {
    await mongoose.connect(process.env.MONGO_URI);
    console.log("✅ MongoDB Connected");
    await Promise.all([User.deleteMany({}), Event.deleteMany({}), Registration.deleteMany({})]);
    console.log("🗑️  Cleared existing data");
    const insertedUsers = await Promise.all(USERS.map(async u => {
      const hash = await bcrypt.hash(u.password, 12);
      return User.create({ ...u, password: hash });
    }));
    console.log("👤 Inserted " + insertedUsers.length + " users");
    const organizer = insertedUsers.find(u => u.role === "organizer");
    const eventsToInsert = EVENTS.map(e => ({ ...e, startDate: new Date(e.startDate), endDate: new Date(e.endDate), organizer: organizer._id, registrations: [] }));
    const insertedEvents = await Event.insertMany(eventsToInsert);
    console.log("📅 Inserted " + insertedEvents.length + " events");
    const students = insertedUsers.filter(u => u.role === "student");
    const upcoming  = insertedEvents.filter(e => e.isUpcoming).slice(0, 6);
    for (const student of students) {
      for (const ev of upcoming.slice(0, 3)) {
        await Registration.create({ user: student._id, event: ev._id });
        await Event.findByIdAndUpdate(ev._id, { $addToSet: { registrations: student._id } });
      }
    }
    console.log("🎟️  Added sample registrations");
    console.log("\n━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━");
    console.log("LOGIN CREDENTIALS");
    console.log("━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━");
    console.log("🎓 STUDENTS (password: student123)");
    console.log("   snehitha@vignan.ac.in | ravi@vignan.ac.in | ananya@vignan.ac.in");
    console.log("   kiran@vignan.ac.in    | divya@vignan.ac.in");
    console.log("\n🏛️  ORGANIZERS (password: organizer123)");
    console.log("   prasad@vignan.ac.in | lakshmi@vignan.ac.in | ramesh@vignan.ac.in");
    console.log("\n🌐 EXTERNAL (password: external123)");
    console.log("   arjun@gmail.com | priya@gmail.com | rahul@gmail.com");
    console.log("━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━");
    console.log("\n✅ Seed complete! 50 events + 11 users ready.");
    process.exit(0);
  } catch (err) {
    console.error("❌ Seed failed:", err.message);
    process.exit(1);
  }
}
seed();

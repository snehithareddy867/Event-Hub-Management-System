/* ============================================================
   dashboard.js – Full Dashboard Logic (V2 – 2026 Edition)
   ============================================================ */

const API_FALLBACK_EVENTS = [
  { _id:"1", title:"TechFest 2026", category:"technical", startDate:"2026-09-10T09:00:00", endDate:"2026-09-12T18:00:00", venue:"Main Auditorium", maxCapacity:800, isUpcoming:true, shortDesc:"Annual flagship tech fest with 50+ events.", description:"TechFest 2026 is Vignan's premier technical festival featuring hackathons, robotics challenges, coding contests and talks from top industry leaders.", coverImage:"https://images.unsplash.com/photo-1540575467063-178a50c2df87?w=400&q=80", contactInfo:"techfest@vignan.ac.in", registrations:[] },
  { _id:"2", title:"Cultural Night 2026", category:"cultural", startDate:"2026-10-15T17:00:00", endDate:"2026-10-15T22:00:00", venue:"Open Air Theatre", maxCapacity:1500, isUpcoming:true, shortDesc:"Grand cultural extravaganza with celebrity performers.", description:"A spectacular evening of music, dance, drama, fashion and celebrity performances celebrating the rich cultural diversity of Vignan.", coverImage:"https://images.unsplash.com/photo-1492684223066-81342ee5ff30?w=400&q=80", contactInfo:"cultural@vignan.ac.in", registrations:[] },
  { _id:"3", title:"Sports Carnival 2026", category:"sports", startDate:"2026-11-14T07:00:00", endDate:"2026-11-16T18:00:00", venue:"Sports Complex", maxCapacity:1000, isUpcoming:true, shortDesc:"Inter-college sports meet across 20+ disciplines.", description:"Vignan's biggest sporting event bringing together students from 30+ colleges. 20+ sports disciplines, medal ceremony and prizes.", coverImage:"https://images.unsplash.com/photo-1461896836934-ffe607ba8211?w=400&q=80", contactInfo:"sports@vignan.ac.in", registrations:[] },
  { _id:"4", title:"AI and Future of Work", category:"seminar", startDate:"2026-05-08T09:30:00", endDate:"2026-05-08T17:00:00", venue:"Conference Hall A", maxCapacity:350, isUpcoming:true, shortDesc:"Industry leaders discuss AI impact on jobs and skills.", description:"A full-day seminar featuring keynotes, panel discussions and Q&A on how AI is transforming industries.", coverImage:"https://images.unsplash.com/photo-1485827404703-89b55fcc595e?w=400&q=80", contactInfo:"aiml@vignan.ac.in", registrations:[] },
  { _id:"5", title:"React.js Bootcamp", category:"workshop", startDate:"2026-04-25T10:00:00", endDate:"2026-04-26T17:00:00", venue:"Lab Block 3", maxCapacity:60, isUpcoming:true, shortDesc:"2-day hands-on React.js development workshop.", description:"Build real React projects from scratch. Covers hooks, state management, API integration and deployment.", coverImage:"https://images.unsplash.com/photo-1517048676732-d65bc937f952?w=400&q=80", contactInfo:"workshops@vignan.ac.in", registrations:[] },
  { _id:"6", title:"Hackathon 2026", category:"technical", startDate:"2026-04-18T09:00:00", endDate:"2026-04-19T09:00:00", venue:"Innovation Lab", maxCapacity:200, isUpcoming:true, shortDesc:"48-hour hackathon with Rs.5L prizes.", description:"Teams of 3-4 build real-world solutions in 48 hours. Mentors from Google, Microsoft and Amazon.", coverImage:"https://images.unsplash.com/photo-1504384308090-c894fdcc538d?w=400&q=80", contactInfo:"hackathon@vignan.ac.in", registrations:[] },
];

let allEvents      = [];
let myEvents       = [];
let currentUser    = null;
let currentEventId = null;

const SECTION_META = {
  overview:       { title:"Overview",            sub:"Your dashboard at a glance" },
  events:         { title:"All Events",           sub:"Browse and register for events" },
  "my-events":    { title:"My Registrations",     sub:"Events you have registered for" },
  schedule:       { title:"Schedule",             sub:"Upcoming event timeline" },
  profile:        { title:"Profile",              sub:"Your account details" },
  location:       { title:"Location",             sub:"How to reach Vignan University" },
  contacts:       { title:"Contacts",             sub:"Get in touch with event team" },
  "create-event": { title:"Create Event",         sub:"Organizer: publish a new event" },
  "manage-events":{ title:"Manage Events",        sub:"Organizer: view registrations & stats" },
  "hospitality":  { title:"Hospitality",          sub:"Accommodation, mess & transport info" },
  "city-map":     { title:"City Map",             sub:"Navigate Guntur city & nearby landmarks" },
  "food":         { title:"Food Menu",            sub:"Food types & menu available on campus" },
};

function navigate(sectionId) {
  document.querySelectorAll(".s-link").forEach(l => l.classList.toggle("active", l.dataset.section === sectionId));
  document.querySelectorAll(".dash-section").forEach(s => { s.classList.remove("active"); s.style.display = ""; });
  const sec = document.getElementById("sec-" + sectionId);
  if (sec) { sec.classList.add("active"); sec.style.display = "block"; }
  const meta = SECTION_META[sectionId] || {};
  document.getElementById("dash-page-title").textContent = meta.title || sectionId;
  document.getElementById("dash-page-sub").textContent   = meta.sub   || "";
  loadSection(sectionId);
  document.getElementById("sidebar").classList.remove("open");
}

function loadSection(id) {
  switch(id) {
    case "overview":      renderOverview();      break;
    case "events":        renderEventsGrid();    break;
    case "my-events":     loadMyEvents();        break;
    case "schedule":      renderSchedule();      break;
    case "profile":       loadProfile();         break;
    case "manage-events": renderManageEvents();  break;
    case "hospitality":   loadHospitality();     break;
    case "city-map":      /* static content */   break;
    case "food":          /* static content */   break;
  }
}

function checkAuth() {
  if (!Session.isLoggedIn()) {
    showToast("Please sign in to access the dashboard.", "error");
    setTimeout(() => window.location.href = "index.html", 1200);
    return false;
  }
  currentUser = Session.get();
  return true;
}

function fillSidebarUser() {
  const u = currentUser;
  if (!u) return;
  document.getElementById("su-name").textContent   = u.name;
  document.getElementById("su-role").textContent   = u.role;
  document.getElementById("su-avatar").textContent = u.name.charAt(0).toUpperCase();

  if (u.role === "organizer") {
    // Show organizer-only nav items
    document.querySelectorAll(".organizer-only").forEach(el => el.style.display = "");

    // Hide all non-organizer nav links (keep only profile, create-event, manage-events, schedule)
    const ORGANIZER_SECTIONS = ["profile", "create-event", "manage-events", "schedule"];
    document.querySelectorAll(".s-link").forEach(link => {
      const sec = link.dataset.section;
      if (!ORGANIZER_SECTIONS.includes(sec)) {
        link.style.display = "none";
      }
    });

    // Add organizer badge to sidebar if not already present
    if (!document.getElementById("org-sidebar-badge")) {
      const badge = document.createElement("div");
      badge.id = "org-sidebar-badge";
      badge.className = "org-sidebar-badge";
      badge.innerHTML = '<span class="org-badge-dot"></span> Organizer Panel';
      const nav = document.querySelector(".sidebar-nav");
      nav.parentNode.insertBefore(badge, nav);
    }

    // Update topbar button for organizer
    const topBtn = document.querySelector(".dash-topbar-right .btn-accent");
    if (topBtn) { topBtn.textContent = "➕ New Event"; topBtn.onclick = () => navigate("create-event"); }

    // Update section meta for schedule
    SECTION_META["schedule"] = { title: "Event Schedule", sub: "Full poster-style event calendar" };
  }

  if (u.role === "student" || u.role === "organizer") {
    document.querySelectorAll(".vignan-only").forEach(el => el.style.display = "none");
  }
  if (u.role === "external" || u.role === "external_student" || u.role === "external-student") {
    // Show hospitality, city map, food links for external students
    document.querySelectorAll(".external-only").forEach(el => el.style.display = "");
  }
}

function fmtDate(d)     { return new Date(d).toLocaleDateString("en-IN", { day:"numeric", month:"short", year:"numeric" }); }
function fmtDateTime(d) { return new Date(d).toLocaleString("en-IN", { day:"numeric", month:"short", year:"numeric", hour:"2-digit", minute:"2-digit" }); }
function catEmoji(cat) {
  const map = { technical:"⚙️", cultural:"🎭", sports:"🏅", workshop:"🔧", seminar:"🎤", other:"📌" };
  return map[cat] || "📌";
}

async function fetchAllEvents() {
  try {
    allEvents = await EventsAPI.getAll();
    if (!allEvents || !allEvents.length) allEvents = API_FALLBACK_EVENTS;
  } catch { allEvents = API_FALLBACK_EVENTS; }
}

/* ── Overview ─────────────────────────────────────────────*/
function renderOverview() {
  const upcoming = allEvents.filter(e => e.isUpcoming);
  const past     = allEvents.filter(e => !e.isUpcoming);
  document.getElementById("stat-total").textContent      = allEvents.length;
  document.getElementById("stat-upcoming").textContent   = upcoming.length;
  document.getElementById("stat-past").textContent       = past.length;
  document.getElementById("stat-registered").textContent = myEvents.length;

  const list   = document.getElementById("overview-events-list");
  const shown  = upcoming.slice(0, 5);
  if (!shown.length) {
    list.innerHTML = "<div class='empty-state'><div class='empty-icon'>📅</div><p>No upcoming events found.</p></div>";
    return;
  }
  list.innerHTML = `
    <table class="events-table">
      <thead><tr><th>Event</th><th>Category</th><th>Date</th><th>Venue</th><th>Seats</th><th></th></tr></thead>
      <tbody>
        ${shown.map(ev => `
          <tr>
            <td class="ev-title">${catEmoji(ev.category)} ${ev.title}</td>
            <td><span class="tag tag-cyan">${ev.category}</span></td>
            <td>${fmtDate(ev.startDate)}</td>
            <td>${ev.venue || "Vignan University"}</td>
            <td>${ev.maxCapacity || "—"}</td>
            <td><button class="btn btn-outline btn-sm" onclick="openEventModal('${ev._id}')">View</button></td>
          </tr>`).join("")}
      </tbody>
    </table>`;
}

/* ── Events Grid ──────────────────────────────────────────*/
function renderEventsGrid(filter = "all", search = "") {
  const grid = document.getElementById("dash-events-grid");
  let shown  = [...allEvents];
  if (filter !== "all") shown = shown.filter(e => e.category === filter);
  if (search)           shown = shown.filter(e => e.title.toLowerCase().includes(search.toLowerCase()));
  if (!shown.length) {
    grid.innerHTML = "<div class='empty-state' style='grid-column:1/-1'><div class='empty-icon'>🔍</div><p>No events match your filter.</p></div>";
    return;
  }
  grid.innerHTML = shown.map(ev => buildEventCard(ev)).join("");
}

function buildEventCard(ev) {
  const img = ev.coverImage || "https://images.unsplash.com/photo-1540575467063-178a50c2df87?w=400&q=80";
  const regCount = Array.isArray(ev.registrations) ? ev.registrations.length : 0;
  const pct      = ev.maxCapacity ? Math.min(100, Math.round((regCount / ev.maxCapacity) * 100)) : 0;
  const statusTag = ev.isUpcoming
    ? "<span class='tag tag-green'>Upcoming</span>"
    : "<span class='tag tag-blue'>Past</span>";
  return `
    <div class="card event-card" onclick="openEventModal('${ev._id}')" style="cursor:pointer">
      <div class="card-image">
        <img src="${img}" alt="${ev.title}" loading="lazy" onerror="this.src='https://images.unsplash.com/photo-1540575467063-178a50c2df87?w=400&q=80'"/>
        <div class="card-badge">${catEmoji(ev.category)} ${ev.category}</div>
      </div>
      <div class="card-body">
        <div class="card-meta">📅 ${fmtDate(ev.startDate)}</div>
        <div class="card-title">${ev.title}</div>
        <div class="card-desc">${ev.shortDesc || ev.description || ""}</div>
        <div style="margin-top:8px">
          <div style="display:flex;justify-content:space-between;font-size:0.78rem;color:var(--text-light);margin-bottom:4px">
            <span>👥 ${regCount} registered</span><span>${ev.maxCapacity} seats</span>
          </div>
          <div style="background:var(--bg-off);border-radius:4px;height:5px;overflow:hidden">
            <div style="width:${pct}%;height:100%;background:var(--accent);border-radius:4px;transition:width 0.5s"></div>
          </div>
        </div>
      </div>
      <div class="card-footer">${statusTag}<span style="font-size:0.8rem;color:var(--text-light)">📍 ${ev.venue || "Vignan"}</span></div>
    </div>`;
}

/* ── Open modal ───────────────────────────────────────────*/
function openEventModal(id) {
  const ev = allEvents.find(e => String(e._id) === String(id));
  if (!ev) return;
  currentEventId = id;
  const img = ev.coverImage || "https://images.unsplash.com/photo-1540575467063-178a50c2df87?w=400&q=80";
  const regCount = Array.isArray(ev.registrations) ? ev.registrations.length : 0;
  openModal({
    title:       ev.title,
    image:       img,
    date:        fmtDateTime(ev.startDate) + " → " + fmtDate(ev.endDate),
    category:    ev.category,
    venue:       ev.venue || "Vignan University",
    description: ev.description,
    capacity:    ev.maxCapacity,
  });
  let extra = `<p style="font-size:0.85rem;margin-bottom:6px"><strong>👥 Registered:</strong> ${regCount} / ${ev.maxCapacity || "—"}</p>`;
  if (ev.contactInfo) extra += `<p style="font-size:0.85rem;margin-bottom:6px"><strong>📞 Contact:</strong> ${ev.contactInfo}</p>`;
  const extraEl = document.getElementById("modal-extra");
  if (extraEl) extraEl.innerHTML = extra;
  const regBtn = document.getElementById("modal-register-btn");
  if (regBtn) {
    const alreadyReg = myEvents.some(me => String(me._id) === String(id));
    if (!ev.isUpcoming)  { regBtn.textContent = "🔒 Event Ended"; regBtn.disabled = true; }
    else if (alreadyReg) { regBtn.textContent = "✅ Already Registered"; regBtn.disabled = true; }
    else                 { regBtn.textContent = "🎟️ Register for Event"; regBtn.disabled = false; }
  }
}

/* ── Register ─────────────────────────────────────────────*/
async function registerForEvent() {
  if (!currentEventId) return;
  if (!Session.isLoggedIn()) { showToast("Please sign in to register.", "error"); return; }
  const btn = document.getElementById("modal-register-btn");
  btn.disabled = true; btn.textContent = "Registering…";
  try {
    await EventsAPI.register(currentEventId);
    showToast("Successfully registered! 🎉", "success");
    btn.textContent = "✅ Registered!";
    const ev = allEvents.find(e => String(e._id) === String(currentEventId));
    if (ev) {
      if (!Array.isArray(ev.registrations)) ev.registrations = [];
      ev.registrations.push(currentUser._id);
      if (!myEvents.find(me => String(me._id) === String(currentEventId))) myEvents.push(ev);
      document.getElementById("stat-registered").textContent = myEvents.length;
    }
  } catch (err) {
    showToast(err.message || "Registration failed.", "error");
    btn.disabled = false; btn.textContent = "🎟️ Register for Event";
  }
}

/* ── My Events ────────────────────────────────────────────*/
async function loadMyEvents() {
  const list = document.getElementById("my-events-list");
  list.innerHTML = "<div class='loading-spinner' style='color:#fff;padding:40px 0;text-align:center'>Loading…</div>";
  try { if (Session.isLoggedIn()) myEvents = await UsersAPI.getRegisteredEvents(); }
  catch { myEvents = []; }

  // Set year display
  const yearEl = document.getElementById("my-events-year");
  if (yearEl) yearEl.textContent = new Date().getFullYear();

  if (!myEvents.length) {
    list.innerHTML = `<div class="dark-poster-empty"><div style="font-size:2rem">🎟️</div><p>You haven't registered for any events yet.</p><button class="btn btn-primary btn-sm" style="margin-top:16px" onclick="navigate('events')">Browse Events</button></div>`;
    return;
  }

  const accentColors = ["#f97316","#ec4899","#06b6d4","#a3e635","#f59e0b"];
  list.innerHTML = myEvents.map((ev, i) => {
    const start  = new Date(ev.startDate);
    const mon    = start.toLocaleString("en-IN", { month: "short" }).toUpperCase();
    const day    = String(start.getDate()).padStart(2, "0");
    const accent = accentColors[i % accentColors.length];
    const dividerGrad = `linear-gradient(90deg, ${accentColors[i % accentColors.length]}, ${accentColors[(i+1) % accentColors.length]})`;
    return `
    <div class="dark-poster-row">
      <div class="dark-poster-date-col">
        <div class="dark-poster-month">${mon}</div>
        <div class="dark-poster-day" style="color:${accent}">${day}</div>
      </div>
      <div class="dark-poster-vline"></div>
      <div class="dark-poster-info-col">
        <div class="dark-poster-ev-title">${ev.title.toUpperCase()}</div>
        <div class="dark-poster-ev-meta">${ev.shortDesc || (ev.description || "").substring(0, 100)}</div>
        <div class="dark-poster-ev-sub">📍 ${ev.venue || "Vignan University"} &nbsp;·&nbsp; ${fmtDate(ev.startDate)}</div>
      </div>
      <span class="dark-poster-status ${ev.isUpcoming ? "status-upcoming" : "status-past"}">${ev.isUpcoming ? "Upcoming" : "Past"}</span>
    </div>
    <div class="dark-poster-divider-line" style="background:${dividerGrad}"></div>`;
  }).join("");
}

/* ── Schedule ─────────────────────────────────────────────*/
function renderSchedule() {
  if (currentUser && currentUser.role === "organizer") {
    renderPosterSchedule();
    return;
  }
  // Student / External: dark poster schedule
  document.getElementById("schedule-student-view").style.display   = "";
  document.getElementById("schedule-organizer-view").style.display = "none";
  const container = document.getElementById("schedule-timeline");
  const upcoming  = allEvents.filter(e => e.isUpcoming).sort((a,b) => new Date(a.startDate) - new Date(b.startDate));

  // Set year
  const sYearEl = document.getElementById("sched-student-year");
  if (sYearEl) sYearEl.textContent = new Date().getFullYear();

  if (!upcoming.length) {
    container.innerHTML = `<div class="dark-poster-empty"><div style="font-size:2rem">🗓️</div><p>No upcoming events scheduled.</p></div>`;
    return;
  }
  const accentColors = ["#f97316","#ec4899","#06b6d4","#a3e635","#f59e0b"];
  container.innerHTML = upcoming.map((ev, i) => {
    const start   = new Date(ev.startDate);
    const mon     = start.toLocaleString("en-IN", { month: "short" }).toUpperCase();
    const day     = String(start.getDate()).padStart(2, "0");
    const accent  = accentColors[i % accentColors.length];
    const divGrad = `linear-gradient(90deg,${accentColors[i % accentColors.length]},${accentColors[(i+1) % accentColors.length]})`;
    return `
    <div class="dark-poster-row">
      <div class="dark-poster-date-col">
        <div class="dark-poster-month">${mon}</div>
        <div class="dark-poster-day" style="color:${accent}">${day}</div>
      </div>
      <div class="dark-poster-vline"></div>
      <div class="dark-poster-info-col">
        <div class="dark-poster-ev-title">${ev.title.toUpperCase()}</div>
        <div class="dark-poster-ev-meta">${ev.shortDesc || (ev.description || "").substring(0, 100)}</div>
        <div class="dark-poster-ev-sub">📍 ${ev.venue || "Vignan University"} &nbsp;·&nbsp; ${fmtDate(ev.startDate)} &nbsp;·&nbsp; 👥 ${Array.isArray(ev.registrations) ? ev.registrations.length : 0}/${ev.maxCapacity || "—"}</div>
      </div>
      <button class="btn btn-sm" style="background:transparent;border:1px solid #555;color:#ccc;flex-shrink:0" onclick="openEventModal('${ev._id}')">Details</button>
    </div>
    <div class="dark-poster-divider-line" style="background:${divGrad}"></div>`;
  }).join("");
}

/* ── Poster Schedule (Organizer only) ─────────────────────*/
function renderPosterSchedule() {
  document.getElementById("schedule-student-view").style.display   = "none";
  document.getElementById("schedule-organizer-view").style.display = "";

  const body = document.getElementById("sched-poster-body");
  if (!body) return;

  const upcoming = allEvents
    .filter(e => e.isUpcoming)
    .sort((a, b) => new Date(a.startDate) - new Date(b.startDate));

  if (upcoming.length) {
    const first = new Date(upcoming[0].startDate);
    document.getElementById("sched-month").textContent =
      first.toLocaleString("en-IN", { month: "long" }).toUpperCase();
    document.getElementById("sched-day").textContent = upcoming.length + " EVENTS";
  }

  if (!upcoming.length) {
    body.innerHTML = `<div class="sched-poster-empty">🗓️ No upcoming events scheduled.</div>`;
    return;
  }

  const rightColors = ["color-tan", "color-sage", "color-warm"];
  const leftItems   = upcoming.filter((_, i) => i % 2 === 0);
  const rightItems  = upcoming.filter((_, i) => i % 2 === 1);

  const leftHTML = leftItems.map(ev => {
    const start   = new Date(ev.startDate);
    const end     = new Date(ev.endDate);
    const sDay    = start.getDate();
    const eDay    = end.getDate();
    const dateStr = sDay === eDay ? String(sDay) : `${sDay}–${eDay}`;
    const timeStr = start.toLocaleTimeString("en-IN", { hour:"2-digit", minute:"2-digit" }) + " HRS.";
    return `
      <div class="sched-left-block">
        <div class="sched-left-label">${ev.category.toUpperCase()}</div>
        <div class="sched-left-dates">${dateStr}</div>
        <div class="sched-left-time">${timeStr}</div>
        <div class="sched-left-event-name">${ev.title}</div>
        <div class="sched-left-divider"></div>
        <div class="sched-left-desc">${ev.shortDesc || (ev.description || "").substring(0, 90)}</div>
      </div>`;
  }).join("");

  const rightHTML = rightItems.map((ev, i) => {
    const start     = new Date(ev.startDate);
    const day       = start.getDate();
    const timeStr   = start.toLocaleTimeString("en-IN", { hour:"2-digit", minute:"2-digit" }) + " HRS.";
    const colorClass = rightColors[i % rightColors.length];
    return `
      <div class="sched-right-card">
        <div class="sched-right-num ${colorClass}">${day}</div>
        <div class="sched-right-info">
          <div class="sched-right-name">${ev.title}</div>
          <div class="sched-right-time">${timeStr}</div>
          <div class="sched-right-desc">${ev.shortDesc || (ev.description || "").substring(0, 80)}</div>
        </div>
      </div>`;
  }).join("");

  body.innerHTML = `
    <div class="sched-col-left">${leftHTML || "<div class='sched-poster-empty'>—</div>"}</div>
    <div class="sched-col-right">${rightHTML || "<div class='sched-poster-empty'>—</div>"}</div>`;
}

/* ── Profile ──────────────────────────────────────────────*/
async function loadProfile() {
  let user = currentUser;
  try { if (Session.isLoggedIn()) user = await UsersAPI.getProfile(); } catch {}
  if (!user) return;
  document.getElementById("profile-avatar").textContent     = user.name.charAt(0).toUpperCase();
  document.getElementById("profile-name").textContent       = user.name;
  document.getElementById("profile-email").textContent      = user.email;
  document.getElementById("profile-role-badge").textContent = user.role;
  document.getElementById("det-name").textContent    = user.name;
  document.getElementById("det-email").textContent   = user.email;
  document.getElementById("det-role").textContent    = user.role;
  document.getElementById("det-since").textContent   = user.createdAt ? fmtDate(user.createdAt) : "—";
  document.getElementById("det-updated").textContent = user.updatedAt ? fmtDate(user.updatedAt) : "—";
  if (user.studentId) {
    document.getElementById("det-studentid-row").style.display = "";
    document.getElementById("det-studentid").textContent = user.studentId;
  }
  if (user.college) {
    document.getElementById("det-college-row").style.display = "";
    document.getElementById("det-college").textContent = user.college;
  }
  document.getElementById("ps-registered").textContent = myEvents.length;
  document.getElementById("ps-upcoming").textContent   = myEvents.filter(e => e.isUpcoming).length;
}

/* ── Manage Events (Organizer) ────────────────────────────*/
function renderManageEvents() {
  const container = document.getElementById("manage-events-list");
  if (!container) return;
  if (!allEvents.length) {
    container.innerHTML = "<div class='empty-state'><div class='empty-icon'>📋</div><p>No events found.</p></div>";
    return;
  }
  container.innerHTML = allEvents.map(ev => {
    const regCount = Array.isArray(ev.registrations) ? ev.registrations.length : 0;
    const pct      = ev.maxCapacity ? Math.min(100, Math.round((regCount / ev.maxCapacity) * 100)) : 0;
    return `
    <div class="manage-event-card" style="background:var(--card-bg);border:1px solid var(--border);border-radius:16px;padding:20px;margin-bottom:16px">
      <div style="display:flex;justify-content:space-between;align-items:flex-start;flex-wrap:wrap;gap:12px">
        <div style="flex:1">
          <div style="display:flex;align-items:center;gap:10px;flex-wrap:wrap;margin-bottom:6px">
            <span style="font-size:1rem;font-weight:700;color:var(--text-dark)">${catEmoji(ev.category)} ${ev.title}</span>
            <span class="tag ${ev.isUpcoming ? "tag-green" : "tag-blue"}">${ev.isUpcoming ? "Upcoming" : "Past"}</span>
            <span class="tag tag-cyan">${ev.category}</span>
          </div>
          <div style="font-size:0.83rem;color:var(--text-mid);display:flex;gap:16px;flex-wrap:wrap">
            <span>📅 ${fmtDate(ev.startDate)}</span>
            <span>📍 ${ev.venue || "Vignan"}</span>
            <span>📞 ${ev.contactInfo || "—"}</span>
          </div>
        </div>
        <div style="text-align:right;min-width:140px">
          <div style="font-size:1.6rem;font-weight:800;color:var(--primary)">${regCount}</div>
          <div style="font-size:0.78rem;color:var(--text-light)">of ${ev.maxCapacity || "—"} registered</div>
          <div style="background:var(--bg-off);border-radius:4px;height:6px;margin-top:6px;overflow:hidden">
            <div style="width:${pct}%;height:100%;background:${pct >= 80 ? "#ef4444" : pct >= 50 ? "#f59e0b" : "var(--accent)"};border-radius:4px"></div>
          </div>
          <div style="font-size:0.75rem;color:var(--text-light);margin-top:4px">${pct}% filled</div>
        </div>
      </div>
      <div style="display:flex;gap:8px;margin-top:14px;flex-wrap:wrap">
        <button class="btn btn-outline btn-sm" onclick="loadEventRegistrations('${ev._id}', '${ev.title}')">👥 View Registrations</button>
        <button class="btn btn-outline btn-sm" onclick="openEventModal('${ev._id}')">📋 Details</button>
        <button class="btn btn-sm" style="background:#ef4444;color:#fff;border:none" onclick="deleteEvent('${ev._id}', '${ev.title}')">🗑️ Delete</button>
      </div>
    </div>`;
  }).join("");
}

async function loadEventRegistrations(eventId, eventTitle) {
  const container = document.getElementById("manage-events-list");
  container.innerHTML = "<div class='loading-spinner'>Loading registrations…</div>";
  try {
    const data = await fetch(`${window.API_BASE || "http://localhost:5000/api"}/events/${eventId}/registrations`, {
      headers: { Authorization: "Bearer " + (localStorage.getItem("eh_token") || "") }
    }).then(r => r.json());

    const regs = data.registrations || [];
    container.innerHTML = `
      <div style="margin-bottom:16px;display:flex;align-items:center;gap:12px">
        <button class="btn btn-outline btn-sm" onclick="renderManageEvents()">← Back to Events</button>
        <h3 style="margin:0;color:var(--text-dark)">${eventTitle} — Registrations</h3>
        <span class="tag tag-cyan">${data.total || regs.length} total</span>
      </div>
      ${regs.length === 0 ? "<div class='empty-state'><div class='empty-icon'>👥</div><p>No registrations yet for this event.</p></div>" : `
      <table class="events-table">
        <thead><tr><th>#</th><th>Name</th><th>Email</th><th>Role</th><th>Student ID / College</th><th>Registered At</th></tr></thead>
        <tbody>
          ${regs.map((r, i) => `
            <tr>
              <td>${i + 1}</td>
              <td>${r.user?.name || "—"}</td>
              <td>${r.user?.email || "—"}</td>
              <td><span class="tag tag-cyan">${r.user?.role || "—"}</span></td>
              <td>${r.user?.studentId || r.user?.college || "—"}</td>
              <td>${r.registeredAt ? fmtDate(r.registeredAt) : "—"}</td>
            </tr>`).join("")}
        </tbody>
      </table>`}`;
  } catch (err) {
    container.innerHTML = `<div class='empty-state'><div class='empty-icon'>❌</div><p>Failed to load: ${err.message}</p><button class="btn btn-outline btn-sm" onclick="renderManageEvents()">← Back</button></div>`;
  }
}

async function deleteEvent(id, title) {
  if (!confirm(`Delete "${title}"? This cannot be undone.`)) return;
  try {
    await EventsAPI.delete(id);
    allEvents = allEvents.filter(e => String(e._id) !== String(id));
    showToast(`"${title}" deleted.`, "success");
    renderManageEvents();
  } catch (err) {
    showToast(err.message || "Delete failed.", "error");
  }
}

/* ── Create Event ─────────────────────────────────────────*/
function initCreateEvent() {
  const btn = document.getElementById("create-event-btn");
  if (!btn) return;
  btn.addEventListener("click", async () => {
    const msgEl = document.getElementById("create-event-msg");
    msgEl.innerHTML = "";
    const title       = document.getElementById("ev-title").value.trim();
    const description = document.getElementById("ev-desc").value.trim();
    const shortDesc   = document.getElementById("ev-short").value.trim();
    const category    = document.getElementById("ev-cat").value;
    const startDate   = document.getElementById("ev-start").value;
    const endDate     = document.getElementById("ev-end").value;
    const venue       = document.getElementById("ev-venue").value.trim();
    const maxCapacity = parseInt(document.getElementById("ev-capacity").value) || 500;
    const coverImage  = document.getElementById("ev-img").value.trim();
    const contactInfo = document.getElementById("ev-contact").value.trim();
    if (!title || !description || !category || !startDate || !endDate) {
      msgEl.innerHTML = "<p class='form-error'>Please fill in all required fields (*).</p>"; return;
    }
    if (new Date(endDate) < new Date(startDate)) {
      msgEl.innerHTML = "<p class='form-error'>End date must be after start date.</p>"; return;
    }
    btn.disabled = true; btn.textContent = "Creating…";
    try {
      const ev = await EventsAPI.create({ title, description, shortDesc, category, startDate, endDate, venue, maxCapacity, coverImage, contactInfo, isUpcoming: true });
      allEvents.unshift(ev);
      showToast("Event \"" + ev.title + "\" created! 🎉", "success");
      msgEl.innerHTML = "<p class='form-success' style='margin-bottom:12px'>✅ Event created successfully!</p>";
      ["ev-title","ev-desc","ev-short","ev-start","ev-end","ev-venue","ev-img","ev-contact"].forEach(id => { const el = document.getElementById(id); if (el) el.value = ""; });
      document.getElementById("ev-cat").value = "";
      document.getElementById("ev-capacity").value = "";
    } catch (err) {
      msgEl.innerHTML = "<p class='form-error'>" + (err.message || "Failed to create event.") + "</p>";
    } finally { btn.disabled = false; btn.textContent = "🚀 Create Event"; }
  });
}

function initContactForm() {
  const btn = document.getElementById("contact-send-btn");
  if (!btn) return;
  btn.addEventListener("click", () => {
    const name    = document.getElementById("contact-name").value.trim();
    const subject = document.getElementById("contact-subject").value.trim();
    const msg     = document.getElementById("contact-msg").value.trim();
    if (!name || !subject || !msg) { showToast("Please fill in all fields.", "error"); return; }
    showToast("Message sent! We'll respond within 24 hrs. 📨", "success");
    document.getElementById("contact-name").value = "";
    document.getElementById("contact-subject").value = "";
    document.getElementById("contact-msg").value = "";
  });
}

function initFilterTabs() {
  document.getElementById("event-filter-tabs")?.querySelectorAll(".filter-tab").forEach(tab => {
    tab.addEventListener("click", () => {
      document.querySelectorAll(".filter-tab").forEach(t => t.classList.remove("active"));
      tab.classList.add("active");
      renderEventsGrid(tab.dataset.filter, document.getElementById("event-search").value);
    });
  });
  document.getElementById("event-search")?.addEventListener("input", e => {
    const active = document.querySelector(".filter-tab.active")?.dataset.filter || "all";
    renderEventsGrid(active, e.target.value);
  });
}

function initDateDisplay() {
  const el = document.getElementById("dash-date");
  if (!el) return;
  el.textContent = new Date().toLocaleDateString("en-IN", { weekday:"long", day:"numeric", month:"long", year:"numeric" });
}

function initSidebarNav() {
  document.querySelectorAll(".s-link").forEach(link => {
    link.addEventListener("click", e => { e.preventDefault(); navigate(link.dataset.section); });
  });
  document.getElementById("logout-btn")?.addEventListener("click", () => {
    Session.clear();
    showToast("Signed out. See you again! 👋", "info");
    setTimeout(() => window.location.href = "index.html", 800);
  });
  document.getElementById("sidebar-toggle")?.addEventListener("click", () => {
    document.getElementById("sidebar").classList.toggle("open");
  });
}

document.addEventListener("DOMContentLoaded", () => {
  const regBtn = document.getElementById("modal-register-btn");
  if (regBtn) regBtn.addEventListener("click", registerForEvent);
});

/* ── Hospitality (External Student) ───────────────────────*/
async function loadHospitality() {
  // The hospitality section is now static HTML — nothing to dynamically load.
  // If a legacy #hospitality-list element exists, populate it with event info.
  const list = document.getElementById("hospitality-list");
  if (!list) return;
  const events = myEvents.length ? myEvents : allEvents.filter(e => e.isUpcoming).slice(0, 3);
  if (!events.length) {
    list.innerHTML = `<div class="dark-poster-empty"><p>Register for an event to see accommodation info.</p></div>`;
    return;
  }
  const accentColors = ["#06b6d4","#8b5cf6","#f97316","#ec4899","#a3e635"];
  list.innerHTML = events.map((ev, i) => {
    const start  = new Date(ev.startDate);
    const mon    = start.toLocaleString("en-IN", { month: "short" }).toUpperCase();
    const day    = String(start.getDate()).padStart(2, "0");
    const accent = accentColors[i % accentColors.length];
    const divGrad = `linear-gradient(90deg,${accentColors[i % accentColors.length]},${accentColors[(i+1) % accentColors.length]})`;
    const accomText = ev.accommodation || ev.howToReach
      ? (ev.accommodation || "") + (ev.howToReach ? " · How to reach: " + ev.howToReach : "")
      : "Contact hospitality desk for accommodation details for this event.";
    return `
    <div class="dark-poster-row">
      <div class="dark-poster-date-col">
        <div class="dark-poster-month">${mon}</div>
        <div class="dark-poster-day" style="color:${accent}">${day}</div>
      </div>
      <div class="dark-poster-vline"></div>
      <div class="dark-poster-info-col">
        <div class="dark-poster-ev-title">${ev.title.toUpperCase()}</div>
        <div class="dark-poster-ev-meta">${accomText}</div>
        <div class="dark-poster-ev-sub">📍 ${ev.venue || "Vignan University"} &nbsp;·&nbsp; 📞 ${ev.contactInfo || "hospitality@vignan.ac.in"}</div>
      </div>
    </div>
    <div class="dark-poster-divider-line" style="background:${divGrad}"></div>`;
  }).join("");
}

async function init() {
  if (!checkAuth()) return;
  fillSidebarUser();
  initDateDisplay();
  initSidebarNav();
  initFilterTabs();
  initCreateEvent();
  initContactForm();
  await fetchAllEvents();
  try { if (Session.isLoggedIn()) myEvents = await UsersAPI.getRegisteredEvents(); } catch { myEvents = []; }
  navigate(currentUser && currentUser.role === "organizer" ? "profile" : "overview");
}

document.addEventListener("DOMContentLoaded", init);

/* ============================================================
   gallery.js – Image gallery slider + modal trigger
   ============================================================ */

const GALLERY_EVENTS = [
  { id: 1, title: 'TechFest 2024',        category: 'Technical',  date: 'Mar 15, 2024', desc: 'Annual technical festival featuring hackathons, robotics, coding contests and workshops by industry experts.', img: 'https://images.unsplash.com/photo-1540575467063-178a50c2df87?w=600&q=80' },
  { id: 2, title: 'Cultural Fiesta',       category: 'Cultural',   date: 'Feb 22, 2024', desc: 'A vibrant celebration of arts, music, dance, and cultural performances by students from across the university.', img: 'https://images.unsplash.com/photo-1492684223066-81342ee5ff30?w=600&q=80' },
  { id: 3, title: 'Sports Day 2024',       category: 'Sports',     date: 'Jan 20, 2024', desc: 'Inter-department sports competition featuring cricket, football, athletics, badminton and many more events.', img: 'https://images.unsplash.com/photo-1461896836934-ffe607ba8211?w=600&q=80' },
  { id: 4, title: 'IEEE Workshop',         category: 'Workshop',   date: 'Apr 05, 2024', desc: 'Hands-on workshop on embedded systems and IoT conducted by IEEE student branch in collaboration with industry.', img: 'https://images.unsplash.com/photo-1517048676732-d65bc937f952?w=600&q=80' },
  { id: 5, title: 'Entrepreneurship Summit', category: 'Seminar', date: 'May 10, 2024', desc: 'Industry leaders, startup founders and innovators share their journeys in this inspiring entrepreneurship summit.', img: 'https://images.unsplash.com/photo-1475721027785-f74eccf877e2?w=600&q=80' },
  { id: 6, title: 'AI & ML Conference',   category: 'Technical',  date: 'Jun 18, 2024', desc: 'Deep dive into artificial intelligence and machine learning with live demos, paper presentations and keynotes.', img: 'https://images.unsplash.com/photo-1485827404703-89b55fcc595e?w=600&q=80' },
  { id: 7, title: 'Alumni Meet 2024',      category: 'Cultural',   date: 'Jul 07, 2024', desc: 'Grand reunion of Vignan alumni from across the globe, featuring networking, awards and nostalgic performances.', img: 'https://images.unsplash.com/photo-1529156069898-49953e39b3ac?w=600&q=80' },
  { id: 8, title: 'Hackathon 48Hr',        category: 'Technical',  date: 'Aug 02, 2024', desc: '48-hour non-stop hackathon with exciting challenges, prizes worth ₹5 Lakhs and mentorship from top engineers.', img: 'https://images.unsplash.com/photo-1504384308090-c894fdcc538d?w=600&q=80' },
];

let currentSlide = 0;
const VISIBLE = 4;

function buildGallery() {
  const track = document.getElementById('gallery-track');
  if (!track) return;

  track.innerHTML = GALLERY_EVENTS.map((ev, i) => `
    <div class="gallery-item" data-index="${i}" role="button" tabindex="0" aria-label="${ev.title}">
      <img src="${ev.img}" alt="${ev.title}" loading="lazy" />
      <div class="gallery-item-overlay">
        <div>
          <span class="tag tag-cyan" style="margin-bottom:4px">${ev.category}</span>
          <div class="gallery-item-title">${ev.title}</div>
        </div>
      </div>
    </div>
  `).join('');

  // Click listeners
  track.querySelectorAll('.gallery-item').forEach(item => {
    item.addEventListener('click',  () => openGalleryModal(+item.dataset.index));
    item.addEventListener('keydown', e => { if (e.key === 'Enter') openGalleryModal(+item.dataset.index); });
  });
}

function slideGallery(dir) {
  const track = document.getElementById('gallery-track');
  if (!track) return;
  const maxSlide = GALLERY_EVENTS.length - VISIBLE;
  currentSlide = Math.max(0, Math.min(currentSlide + dir, maxSlide));
  const itemW = track.children[0]?.offsetWidth + 20 || 320; // 20 = gap
  track.style.transform = `translateX(-${currentSlide * itemW}px)`;
}

function openGalleryModal(index) {
  const ev = GALLERY_EVENTS[index];
  if (!ev) return;
  // Uses modal.js openModal()
  if (typeof openModal === 'function') {
    openModal({
      title: ev.title,
      image: ev.img,
      date:  ev.date,
      category: ev.category,
      description: ev.desc,
    });
  }
}

// Auto-slide every 4s
let autoSlide;
function startAutoSlide() {
  autoSlide = setInterval(() => {
    if (currentSlide >= GALLERY_EVENTS.length - VISIBLE) currentSlide = -1;
    slideGallery(1);
  }, 4000);
}
function stopAutoSlide() { clearInterval(autoSlide); }

document.addEventListener('DOMContentLoaded', () => {
  buildGallery();
  startAutoSlide();

  document.getElementById('gallery-prev')?.addEventListener('click', () => { stopAutoSlide(); slideGallery(-1); startAutoSlide(); });
  document.getElementById('gallery-next')?.addEventListener('click', () => { stopAutoSlide(); slideGallery(1);  startAutoSlide(); });
});

// Expose for use in landing.js
window.GALLERY_EVENTS = GALLERY_EVENTS;

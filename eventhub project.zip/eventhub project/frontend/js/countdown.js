/* ============================================================
   countdown.js – Event countdown timer
   ============================================================ */

/**
 * Initializes a live countdown timer.
 * @param {string} targetDateStr - ISO date string of target event
 * @param {Object} els - { days, hours, mins, secs } DOM elements
 */
function initCountdown(targetDateStr, els) {
  const target = new Date(targetDateStr).getTime();

  function pad(n) { return String(n).padStart(2, '0'); }

  function animatePop(el) {
    el.classList.remove('pop');
    void el.offsetWidth; // reflow
    el.classList.add('pop');
  }

  function tick() {
    const now  = Date.now();
    const diff = target - now;

    if (diff <= 0) {
      els.days.textContent  = '00';
      els.hours.textContent = '00';
      els.mins.textContent  = '00';
      els.secs.textContent  = '00';
      clearInterval(timer);
      const banner = document.getElementById('countdown-banner');
      if (banner) banner.innerHTML = '<p style="color:#ffd700;font-size:1.4rem;font-weight:700">🎉 Event is Live Now!</p>';
      return;
    }

    const d = Math.floor(diff / 86400000);
    const h = Math.floor((diff % 86400000) / 3600000);
    const m = Math.floor((diff % 3600000)  / 60000);
    const s = Math.floor((diff % 60000)    / 1000);

    const newD = pad(d), newH = pad(h), newM = pad(m), newS = pad(s);

    if (els.days.textContent  !== newD) { els.days.textContent  = newD; animatePop(els.days);  }
    if (els.hours.textContent !== newH) { els.hours.textContent = newH; animatePop(els.hours); }
    if (els.mins.textContent  !== newM) { els.mins.textContent  = newM; animatePop(els.mins);  }
    if (els.secs.textContent  !== newS) { els.secs.textContent  = newS; animatePop(els.secs);  }
  }

  tick();
  const timer = setInterval(tick, 1000);
  return timer;
}

// Auto-init when DOM is ready
document.addEventListener('DOMContentLoaded', () => {
  const wrap = document.getElementById('countdown-section');
  if (!wrap) return;

  // Target: next major event (change this to your real date)
  const TARGET_DATE = wrap.dataset.target || '2025-09-15T09:00:00';

  const els = {
    days:  document.getElementById('cd-days'),
    hours: document.getElementById('cd-hours'),
    mins:  document.getElementById('cd-mins'),
    secs:  document.getElementById('cd-secs'),
  };

  if (els.days && els.hours && els.mins && els.secs) {
    initCountdown(TARGET_DATE, els);
  }
});

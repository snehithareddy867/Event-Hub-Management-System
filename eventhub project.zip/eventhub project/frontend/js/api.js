/* ============================================================
   api.js – Central API Layer (Frontend ↔ Backend connector)
   All fetch calls go through here. Change BASE_URL to match
   your server. Default: http://localhost:5000
   ============================================================ */

const API_BASE = 'http://localhost:5000/api';

/* ── Helpers ──────────────────────────────────────────────── */

function getToken() {
  return localStorage.getItem('eh_token') || '';
}

function authHeaders() {
  return {
    'Content-Type': 'application/json',
    'Authorization': `Bearer ${getToken()}`,
  };
}

function jsonHeaders() {
  return { 'Content-Type': 'application/json' };
}

async function handleResponse(res) {
  const data = await res.json().catch(() => ({}));
  if (!res.ok) throw new Error(data.message || `Error ${res.status}`);
  return data;
}

/* ── Auth API ─────────────────────────────────────────────── */

const AuthAPI = {

  async register(payload) {
    // payload: { name, email, password, role, college?, studentId? }
    const res = await fetch(`${API_BASE}/auth/register`, {
      method: 'POST',
      headers: jsonHeaders(),
      body: JSON.stringify(payload),
    });
    return handleResponse(res);
  },

  async login(email, password) {
    const res = await fetch(`${API_BASE}/auth/login`, {
      method: 'POST',
      headers: jsonHeaders(),
      body: JSON.stringify({ email, password }),
    });
    return handleResponse(res);
  },

};

/* ── Events API ───────────────────────────────────────────── */

const EventsAPI = {

  async getAll() {
    const res = await fetch(`${API_BASE}/events`);
    return handleResponse(res);
  },

  async getById(id) {
    const res = await fetch(`${API_BASE}/events/${id}`);
    return handleResponse(res);
  },

  async create(payload) {
    const res = await fetch(`${API_BASE}/events`, {
      method: 'POST',
      headers: authHeaders(),
      body: JSON.stringify(payload),
    });
    return handleResponse(res);
  },

  async update(id, payload) {
    const res = await fetch(`${API_BASE}/events/${id}`, {
      method: 'PUT',
      headers: authHeaders(),
      body: JSON.stringify(payload),
    });
    return handleResponse(res);
  },

  async delete(id) {
    const res = await fetch(`${API_BASE}/events/${id}`, {
      method: 'DELETE',
      headers: authHeaders(),
    });
    return handleResponse(res);
  },

  async register(eventId) {
    const res = await fetch(`${API_BASE}/events/${eventId}/register`, {
      method: 'POST',
      headers: authHeaders(),
    });
    return handleResponse(res);
  },

};

/* ── Users API ────────────────────────────────────────────── */

const UsersAPI = {

  async getProfile() {
    const res = await fetch(`${API_BASE}/users/profile`, {
      headers: authHeaders(),
    });
    return handleResponse(res);
  },

  async getRegisteredEvents() {
    const res = await fetch(`${API_BASE}/users/registered-events`, {
      headers: authHeaders(),
    });
    return handleResponse(res);
  },

};

/* ── Session Helpers ──────────────────────────────────────── */

const Session = {

  save(data) {
    // data: { _id, name, email, role, token }
    localStorage.setItem('eh_token',    data.token);
    localStorage.setItem('eh_user',     JSON.stringify({ _id: data._id, name: data.name, email: data.email, role: data.role }));
  },

  get() {
    try { return JSON.parse(localStorage.getItem('eh_user')); }
    catch { return null; }
  },

  isLoggedIn() {
    return !!localStorage.getItem('eh_token');
  },

  clear() {
    localStorage.removeItem('eh_token');
    localStorage.removeItem('eh_user');
  },

};

/* ── Toast utility (works on both pages) ─────────────────── */

function showToast(message, type = 'info') {
  let container = document.getElementById('toast-container');
  if (!container) {
    container = document.createElement('div');
    container.id = 'toast-container';
    container.className = 'toast-container';
    document.body.appendChild(container);
  }
  const toast = document.createElement('div');
  toast.className = `toast ${type}`;
  const icons = { success: '✅', error: '❌', info: 'ℹ️' };
  toast.innerHTML = `<span>${icons[type] || 'ℹ️'}</span> ${message}`;
  container.appendChild(toast);
  setTimeout(() => { toast.style.opacity = '0'; setTimeout(() => toast.remove(), 400); }, 3500);
}

window.AuthAPI   = AuthAPI;
window.EventsAPI = EventsAPI;
window.UsersAPI  = UsersAPI;
window.Session   = Session;
window.showToast = showToast;

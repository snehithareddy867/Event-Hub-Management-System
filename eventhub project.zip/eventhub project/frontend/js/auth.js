/* ============================================================
   auth.js – Login & Register form handling
   Connects all 3 role tabs (Student / Organizer / External)
   to the real backend API via api.js
   ============================================================ */

/* ── Tab switching ────────────────────────────────────────── */
function initAuthTabs() {
  const tabs = document.querySelectorAll('.auth-tab');
  tabs.forEach(tab => {
    tab.addEventListener('click', () => {
      tabs.forEach(t => t.classList.remove('active'));
      tab.classList.add('active');
      document.querySelectorAll('.auth-pane').forEach(p => p.classList.remove('active'));
      const pane = document.getElementById(tab.dataset.pane);
      if (pane) pane.classList.add('active');
    });
  });
}

/* ── Login / Register toggle per pane ────────────────────── */
function initPaneToggles() {
  document.querySelectorAll('.auth-pane').forEach(pane => {
    const toggleBtns = pane.querySelectorAll('.auth-toggle-btn');
    toggleBtns.forEach(btn => {
      btn.addEventListener('click', () => {
        toggleBtns.forEach(b => b.classList.remove('active'));
        btn.classList.add('active');
        const target = btn.dataset.show;
        pane.querySelectorAll('.login-form, .register-form').forEach(f => {
          f.style.display = f.classList.contains(target) ? 'block' : 'none';
        });
      });
    });
  });
}

/* ── Form validation helpers ──────────────────────────────── */
function setError(id, msg) {
  const el = document.getElementById(id);
  if (el) el.textContent = msg;
}
function clearErrors(...ids) {
  ids.forEach(id => setError(id, ''));
}
function validateEmail(email) {
  return /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email);
}
function setButtonLoading(btn, loading) {
  btn.disabled = loading;
  btn.dataset.original = btn.dataset.original || btn.textContent;
  btn.textContent = loading ? 'Please wait…' : btn.dataset.original;
}

/* ── Generic login handler ────────────────────────────────── */
async function handleLogin(formId, role, emailErrId, pwErrId) {
  const form = document.getElementById(formId);
  if (!form) return;

  form.addEventListener('submit', async (e) => {
    e.preventDefault();
    clearErrors(emailErrId, pwErrId);

    const email    = form.querySelector('[name="email"]').value.trim();
    const password = form.querySelector('[name="password"]').value;
    const btn      = form.querySelector('button[type="submit"]');

    // Validate
    if (!validateEmail(email)) return setError(emailErrId, 'Enter a valid email.');
    if (password.length < 6)   return setError(pwErrId, 'Password must be at least 6 characters.');

    setButtonLoading(btn, true);
    try {
      const data = await AuthAPI.login(email, password);
      Session.save(data);
      showToast(`Welcome back, ${data.name}! 🎉`, 'success');
      setTimeout(() => {
        window.location.href = 'dashboard.html';
      }, 800);
    } catch (err) {
      showToast(err.message || 'Login failed. Check credentials.', 'error');
      setError(pwErrId, err.message || 'Invalid email or password.');
    } finally {
      setButtonLoading(btn, false);
    }
  });
}

/* ── Generic register handler ─────────────────────────────── */
async function handleRegister(formId, role, nameErrId, emailErrId, pwErrId, cpwErrId) {
  const form = document.getElementById(formId);
  if (!form) return;

  form.addEventListener('submit', async (e) => {
    e.preventDefault();
    clearErrors(nameErrId, emailErrId, pwErrId, cpwErrId);

    const name     = form.querySelector('[name="name"]')?.value.trim()     || '';
    const email    = form.querySelector('[name="email"]')?.value.trim()    || '';
    const password = form.querySelector('[name="password"]')?.value        || '';
    const confirm  = form.querySelector('[name="confirm"]')?.value         || '';
    const college  = form.querySelector('[name="college"]')?.value.trim()  || '';
    const studentId= form.querySelector('[name="studentId"]')?.value.trim()|| '';
    const btn      = form.querySelector('button[type="submit"]');

    // Validate
    if (name.length < 2)         return setError(nameErrId, 'Enter your full name.');
    if (!validateEmail(email))   return setError(emailErrId, 'Enter a valid email address.');
    if (password.length < 6)     return setError(pwErrId, 'Password must be at least 6 characters.');
    if (password !== confirm)    return setError(cpwErrId, 'Passwords do not match.');

    const payload = { name, email, password, role };
    if (college)   payload.college   = college;
    if (studentId) payload.studentId = studentId;

    setButtonLoading(btn, true);
    try {
      const data = await AuthAPI.register(payload);
      Session.save(data);
      showToast(`Account created! Welcome, ${data.name} 🎓`, 'success');
      setTimeout(() => {
        window.location.href = 'dashboard.html';
      }, 800);
    } catch (err) {
      showToast(err.message || 'Registration failed.', 'error');
      setError(emailErrId, err.message || 'Could not create account.');
    } finally {
      setButtonLoading(btn, false);
    }
  });
}

/* ── Update navbar if already logged in ─────────────────────*/
function updateNavForSession() {
  const user = Session.get();
  if (!user) return;
  const navCta = document.querySelector('.nav-cta');
  if (navCta) {
    navCta.innerHTML = `
      <span style="font-size:0.85rem;color:rgba(255,255,255,0.8)">Hi, ${user.name.split(' ')[0]}</span>
      <button class="btn btn-accent btn-sm" onclick="window.location.href='dashboard.html'">Dashboard</button>
    `;
  }
}

/* ── Init all forms ───────────────────────────────────────── */
document.addEventListener('DOMContentLoaded', () => {
  initAuthTabs();
  initPaneToggles();
  updateNavForSession();

  // Student
  handleLogin('student-login-form', 'student',
    'student-login-email-error', 'student-login-pw-error');
  handleRegister('student-register-form', 'student',
    'student-reg-name-error', 'student-reg-email-error',
    'student-reg-pw-error',   'student-reg-cpw-error');

  // Organizer
  handleLogin('organizer-login-form', 'organizer',
    'organizer-login-email-error', 'organizer-login-pw-error');
  handleRegister('organizer-register-form', 'organizer',
    'organizer-reg-name-error', 'organizer-reg-email-error',
    'organizer-reg-pw-error',   'organizer-reg-cpw-error');

  // External
  handleLogin('external-login-form', 'external',
    'external-login-email-error', 'external-login-pw-error');
  handleRegister('external-register-form', 'external',
    'external-reg-name-error', 'external-reg-email-error',
    'external-reg-pw-error',   'external-reg-cpw-error');
});

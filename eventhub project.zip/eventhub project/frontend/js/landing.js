/* ============================================================
   landing.js – Populates Events grid on index.html
   and handles hero carousel dot navigation.
   ============================================================ */

/* ── Events Data ──────────────────────────────────────────── */
const LANDING_EVENTS = [
  {
    title: 'TechFest 2025',
    category: 'Technical',
    status: 'Upcoming',
    date: 'Sep 15, 2025',
    venue: 'Main Auditorium',
    capacity: 500,
    desc: 'Annual technical festival with hackathons, robotics, coding contests and workshops by industry experts.',
    img: 'https://images.unsplash.com/photo-1540575467063-178a50c2df87?w=600&q=80',
  },
  {
    title: 'Cultural Night 2025',
    category: 'Cultural',
    status: 'Upcoming',
    date: 'Oct 10, 2025',
    venue: 'Open Air Theatre',
    capacity: 1000,
    desc: 'A vibrant evening of music, dance, drama and art celebrating our campus culture.',
    img: 'https://images.unsplash.com/photo-1492684223066-81342ee5ff30?w=600&q=80',
  },
  {
    title: 'AI & ML Summit',
    category: 'Technical',
    status: 'Upcoming',
    date: 'Nov 05, 2025',
    venue: 'Seminar Hall A',
    capacity: 300,
    desc: 'Deep dive into artificial intelligence with live demos, paper presentations and industry keynotes.',
    img: 'https://images.unsplash.com/photo-1485827404703-89b55fcc595e?w=600&q=80',
  },
  {
    title: 'Sports Carnival 2024',
    category: 'Sports',
    status: 'Past',
    date: 'Jan 20, 2024',
    venue: 'University Grounds',
    capacity: 800,
    desc: 'Inter-department sports competition: cricket, football, athletics, badminton and more.',
    img: 'https://images.unsplash.com/photo-1461896836934-ffe607ba8211?w=600&q=80',
  },
  {
    title: 'Hackathon 48Hr',
    category: 'Technical',
    status: 'Past',
    date: 'Aug 02, 2024',
    venue: 'Innovation Lab',
    capacity: 200,
    desc: '48-hour non-stop hackathon with exciting challenges and prizes worth ₹5 Lakhs.',
    img: 'https://images.unsplash.com/photo-1504384308090-c894fdcc538d?w=600&q=80',
  },
  {
    title: 'Entrepreneurship Summit',
    category: 'Seminar',
    status: 'Past',
    date: 'May 10, 2024',
    venue: 'Conference Hall',
    capacity: 400,
    desc: 'Industry leaders and startup founders share their journeys in this inspiring summit.',
    img: 'https://images.unsplash.com/photo-1475721027785-f74eccf877e2?w=600&q=80',
  },
];

/* ── Category color map ───────────────────────────────────── */
const CAT_COLOR = {
  Technical: '#2e7de9',
  Cultural:  '#a855f7',
  Sports:    '#22c55e',
  Seminar:   '#f59e0b',
  Workshop:  '#06b6d4',
};

/* ── Build Event Cards ────────────────────────────────────── */
function buildEventsGrid(filter = 'all') {
  const grid = document.getElementById('events-grid');
  if (!grid) return;

  const filtered = filter === 'all'
    ? LANDING_EVENTS
    : LANDING_EVENTS.filter(e => e.status.toLowerCase() === filter);

  if (filtered.length === 0) {
    grid.innerHTML = `<p style="text-align:center;color:var(--text-light);grid-column:1/-1">No events found.</p>`;
    return;
  }

  grid.innerHTML = filtered.map((ev, i) => {
    const color     = CAT_COLOR[ev.category] || '#2e7de9';
    const isUpcoming = ev.status === 'Upcoming';
    const tagBg     = isUpcoming ? '#22c55e' : '#64748b';

    return `
    <div class="event-card" data-index="${i}" style="
      background:#fff;
      border-radius:18px;
      overflow:hidden;
      box-shadow:0 4px 24px rgba(0,0,0,0.08);
      display:flex;
      flex-direction:column;
      transition:transform 0.3s ease, box-shadow 0.3s ease;
      cursor:pointer;
    "
    onmouseenter="this.style.transform='translateY(-6px)';this.style.boxShadow='0 12px 40px rgba(0,0,0,0.14)'"
    onmouseleave="this.style.transform='translateY(0)';this.style.boxShadow='0 4px 24px rgba(0,0,0,0.08)'"
    onclick="openEventModal(${i})">
      <div style="position:relative;height:200px;overflow:hidden;">
        <img src="${ev.img}" alt="${ev.title}" loading="lazy"
          style="width:100%;height:100%;object-fit:cover;transition:transform 0.5s ease;"
          onmouseenter="this.style.transform='scale(1.06)'"
          onmouseleave="this.style.transform='scale(1)'"
        />
        <span class="tag" style="
          position:absolute;top:14px;left:14px;
          background:${tagBg};color:#fff;
          padding:4px 12px;border-radius:20px;
          font-size:0.75rem;font-weight:600;letter-spacing:0.04em;
        ">${ev.status}</span>
        <span style="
          position:absolute;top:14px;right:14px;
          background:${color};color:#fff;
          padding:4px 12px;border-radius:20px;
          font-size:0.75rem;font-weight:600;
        ">${ev.category}</span>
      </div>
      <div style="padding:20px;flex:1;display:flex;flex-direction:column;gap:8px;">
        <h3 style="margin:0;font-size:1.1rem;font-weight:700;color:#0a2463;">${ev.title}</h3>
        <div style="display:flex;gap:16px;flex-wrap:wrap;font-size:0.82rem;color:#64748b;">
          <span>📅 ${ev.date}</span>
          <span>📍 ${ev.venue}</span>
          <span>👥 ${ev.capacity} seats</span>
        </div>
        <p style="font-size:0.88rem;color:#475569;line-height:1.6;margin:0;flex:1;">${ev.desc}</p>
        <button class="btn btn-primary" style="
          margin-top:12px;width:100%;justify-content:center;
          background:linear-gradient(135deg,#2e7de9,#0a2463);
          border:none;padding:10px 20px;border-radius:10px;
          color:#fff;font-weight:600;cursor:pointer;font-size:0.9rem;
        "
        onclick="event.stopPropagation();window.location.href='dashboard.html'">
          View Details →
        </button>
      </div>
    </div>`;
  }).join('');
}

/* ── Open event in modal ──────────────────────────────────── */
function openEventModal(index) {
  const ev = LANDING_EVENTS[index];
  if (!ev || typeof openModal !== 'function') return;
  openModal({
    title:       ev.title,
    image:       ev.img,
    date:        ev.date,
    category:    ev.category,
    venue:       ev.venue,
    capacity:    ev.capacity,
    description: ev.desc,
  });
}

/* ── Filter handler (called from inline buttons) ─────────── */
window.filterEvents = function(filter, btn) {
  document.querySelectorAll('.events-section .btn-sm').forEach(b => {
    b.classList.remove('btn-primary');
    b.classList.add('btn-outline');
  });
  btn.classList.remove('btn-outline');
  btn.classList.add('btn-primary');
  buildEventsGrid(filter);
};

/* ── Hero carousel dots ───────────────────────────────────── */
function initHeroDots() {
  const slides = document.querySelectorAll('.hero-slide');
  const dots   = document.querySelectorAll('.hero-dot');
  if (!slides.length) return;

  let current = 0;

  function goTo(n) {
    slides[current].classList.remove('active');
    dots[current]?.classList.remove('active');
    current = (n + slides.length) % slides.length;
    slides[current].classList.add('active');
    dots[current]?.classList.add('active');
  }

  // Auto-rotate every 5s
  setInterval(() => goTo(current + 1), 5000);

  // Dot click
  dots.forEach((dot, i) => dot.addEventListener('click', () => goTo(i)));
}

/* ── Scroll-reveal (lightweight, no library needed) ─────── */
function initScrollReveal() {
  const els = document.querySelectorAll('[data-aos]');
  if (!els.length) return;

  // Set initial state
  els.forEach(el => {
    el.style.opacity  = '0';
    el.style.transform = el.dataset.aos === 'fade-right' ? 'translateX(-40px)'
                       : el.dataset.aos === 'fade-left'  ? 'translateX(40px)'
                       : 'translateY(30px)';
    el.style.transition = 'opacity 0.7s ease, transform 0.7s ease';
  });

  const observer = new IntersectionObserver(entries => {
    entries.forEach(entry => {
      if (entry.isIntersecting) {
        const delay = entry.target.dataset.aosDelay || 0;
        setTimeout(() => {
          entry.target.style.opacity   = '1';
          entry.target.style.transform = 'none';
        }, +delay);
        observer.unobserve(entry.target);
      }
    });
  }, { threshold: 0.15 });

  els.forEach(el => observer.observe(el));
}

/* ── Sticky navbar shadow on scroll ─────────────────────── */
function initNavScroll() {
  const nav = document.getElementById('landing-nav');
  if (!nav) return;
  window.addEventListener('scroll', () => {
    nav.style.boxShadow = window.scrollY > 40
      ? '0 4px 30px rgba(0,0,0,0.18)'
      : 'none';
  });
}

/* ── Init ────────────────────────────────────────────────── */
document.addEventListener('DOMContentLoaded', () => {
  buildEventsGrid('all');
  initHeroDots();
  initScrollReveal();
  initNavScroll();
});

/* ============================================================
   modal.js – Reusable modal popup system
   ============================================================ */

/**
 * Opens a modal with event data
 * @param {{ title, image, date, category, description, venue, capacity }} data
 */
function openModal(data) {
  const overlay = document.getElementById('event-modal');
  if (!overlay) return;

  overlay.querySelector('.modal-image').src = data.image || '';
  overlay.querySelector('.modal-image').alt = data.title || '';
  overlay.querySelector('#modal-title').textContent = data.title || '';
  overlay.querySelector('#modal-date').textContent   = data.date || '';
  overlay.querySelector('#modal-cat').textContent    = data.category || '';
  overlay.querySelector('#modal-venue').textContent  = data.venue || 'Vignan University';
  overlay.querySelector('#modal-desc').textContent   = data.description || '';

  if (data.capacity) {
    const cap = overlay.querySelector('#modal-cap');
    if (cap) cap.textContent = data.capacity;
  }

  overlay.classList.add('active');
  document.body.style.overflow = 'hidden';
}

function closeModal() {
  const overlay = document.getElementById('event-modal');
  if (!overlay) return;
  overlay.classList.remove('active');
  document.body.style.overflow = '';
}

document.addEventListener('DOMContentLoaded', () => {
  const overlay = document.getElementById('event-modal');
  if (!overlay) return;

  // Close on backdrop click
  overlay.addEventListener('click', e => { if (e.target === overlay) closeModal(); });

  // Close button
  overlay.querySelector('.modal-close')?.addEventListener('click', closeModal);

  // ESC key
  document.addEventListener('keydown', e => { if (e.key === 'Escape') closeModal(); });
});
